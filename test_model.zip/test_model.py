import joblib
import pandas as pd

# Load trained artifacts
model = joblib.load('insider_threat_model.pkl')
scaler = joblib.load('feature_scaler.pkl')

print("✅ Model and scaler loaded!")


test_user = pd.DataFrame([{
    'total_emails': 28,
    'avg_emails_per_day': 12.0,
    'recent_email_count': 30,
    'avg_email_size': 4200,
    'max_email_size': 15000,
    'attachment_rate': 0.12,
    'after_hours_ratio': 0.05,
    'weekend_ratio': 0.03,
    'recipient_diversity': 0.18,
    'content_length_std': 20,
    'hour_std': 1.8,
    'unusual_hour_emails': 0.02,
    'size_change_ratio': 0.15
}])

test_user_scaled = scaler.transform(test_user)
anomaly_score = model.decision_function(test_user_scaled)
prediction = model.predict(test_user_scaled)

is_threat = (prediction[0] == -1)

print("Anomaly Score:", anomaly_score[0])
print("Threat Detected:", is_threat)

if anomaly_score[0] < -0.15:
    level = "🔴 HIGH"
elif anomaly_score[0] < 0:
    level = "🟠 MEDIUM"
else:
    level = "🟢 LOW"

print("Threat Level:", level)
