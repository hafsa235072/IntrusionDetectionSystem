# UBA for Insider Threats

## Project Overview

The **UBA (User Behavior Analytics) for Insider Threats** project detects potentially malicious or risky behavior of users within an organization by analyzing email activity and usage patterns. The system leverages a pre-trained machine learning model to assign an **anomaly score** for user behavior and classify the threat level.

---

## Files in the Project

| File                       | Description                                        |
| -------------------------- | -------------------------------------------------- |
| `.venv/`                   | Python virtual environment containing dependencies |
| `feature_scaler.pkl`       | Pre-fitted scaler used to normalize input features |
| `insider_threat_model.pkl` | Pre-trained ML model for anomaly detection         |
| `model_metadata.json`      | Metadata for model and feature information         |
| `requirements.txt`         | Python package dependencies                        |
| `test_model.py`            | Script to load the model and test it               |

---

## Installation

1. Clone the project folder.
2. Navigate to the project directory in terminal/PowerShell.
3. Create and activate a virtual environment:

   ```bash
   python -m venv .venv
   .\.venv\Scripts\activate   # Windows
   source .venv/bin/activate  # Linux/macOS
   ```
4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

---

## Usage

The `test_model.py` script allows you to load the model and evaluate user features.

### Threat Levels

The model returns an **anomaly score** which maps to threat levels as follows:

```python
if anomaly_score <= -0.22:
    threat_level = "CRITICAL"
elif anomaly_score <= -0.21:
    threat_level = "HIGH"
elif anomaly_score <= -0.20:
    threat_level = "MEDIUM"
else:
    threat_level = "LOW"
```

---

## Example: Testing User Features

You can test different user profiles by passing them to the model.

### CRITICAL

```python
user_features = {
    "total_emails": 7,
    "avg_emails_per_day": 7.0,
    "recent_email_count": 7,
    "avg_email_size": 29064.4,
    "max_email_size": 44345,
    "attachment_rate": 0.0,
    "after_hours_ratio": 1.0,
    "weekend_ratio": 1.0,
    "recipient_diversity": 1.0,
    "content_length_std": 50.1,
    "avg_content_length": 348.4,
    "hour_std": 0.0,
    "unusual_hour_emails": 0.0,
    "size_change_ratio": 0.0
}
```

### HIGH

```python
user_features = {
    "total_emails": 300,
    "avg_emails_per_day": 6.0,
    "recent_email_count": 40,
    "avg_email_size": 4200.0,
    "max_email_size": 9000,
    "attachment_rate": 0.08,
    "after_hours_ratio": 0.03,
    "weekend_ratio": 0.04,
    "recipient_diversity": 0.18,
    "content_length_std": 25.0,
    "avg_content_length": 140.0,
    "hour_std": 3.0,
    "unusual_hour_emails": 0.02,
    "size_change_ratio": 0.05
}
```

### MEDIUM

```python
user_features = {
    "total_emails": 500,
    "avg_emails_per_day": 8.0,
    "recent_email_count": 60,
    "avg_email_size": 3800.0,
    "max_email_size": 7500,
    "attachment_rate": 0.06,
    "after_hours_ratio": 0.02,
    "weekend_ratio": 0.03,
    "recipient_diversity": 0.15,
    "content_length_std": 20.0,
    "avg_content_length": 120.0,
    "hour_std": 3.5,
    "unusual_hour_emails": 0.01,
    "size_change_ratio": 0.03
}
```

### LOW

```python
user_features = {
    "total_emails": 5000,
    "avg_emails_per_day": 8.0,
    "recent_email_count": 60,
    "avg_email_size": 3800.0,
    "max_email_size": 7500,
    "attachment_rate": 0.06,
    "after_hours_ratio": 0.02,
    "weekend_ratio": 0.03,
    "recipient_diversity": 0.15,
    "content_length_std": 20.0,
    "avg_content_length": 120.0,
    "hour_std": 3.5,
    "unusual_hour_emails": 0.01,
    "size_change_ratio": 0.03
}
```

---

## How to Run

1. Open a terminal in the project folder.
2. Activate the virtual environment.
3. Run the test script:

```bash
python test_model.py
```

It will load the scaler and model, process your input features, calculate an anomaly score, and print the **threat level**.

