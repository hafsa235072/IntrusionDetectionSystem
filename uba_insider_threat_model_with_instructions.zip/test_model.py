import json
import joblib
import numpy as np

# -----------------------------
# Load artifacts
# -----------------------------
MODEL_PATH = "insider_threat_model.pkl"
SCALER_PATH = "feature_scaler.pkl"
METADATA_PATH = "model_metadata.json"

model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)

with open(METADATA_PATH, "r") as f:
    metadata = json.load(f)

feature_columns = metadata["feature_columns"]

# -----------------------------
# HARD-CODED USER FEATURES
# 👇 EDIT THESE VALUES ONLY
# -----------------------------
user_features = {
    "total_emails": 5000,
    "avg_emails_per_day": 8.0,
    "recent_email_count": 60,
    "avg_email_size": 3800.0,
    "max_email_size": 7500,
    "attachment_rate": 0.06,
    "after_hours_ratio": 0.02,
    "weekend_ratio": 0.03,
    "recipient_diversity": 0.15,
    "content_length_std": 20.0,
    "avg_content_length": 120.0,
    "hour_std": 3.5,
    "unusual_hour_emails": 0.01,
    "size_change_ratio": 0.03
}



# -----------------------------
# Build feature vector
# -----------------------------
X = np.array(
    [user_features.get(col, 0.0) for col in feature_columns],
    dtype=float
).reshape(1, -1)

# Scale
X_scaled = scaler.transform(X)

# Predict
anomaly_score = float(model.decision_function(X_scaled)[0])
raw_pred = int(model.predict(X_scaled)[0])
predicted_anomaly = 1 if raw_pred == -1 else 0

# Threat level logic
if anomaly_score <= -0.22:
    threat_level = "CRITICAL"
elif anomaly_score <= -0.21:
    threat_level = "HIGH"
elif anomaly_score <= -0.20:
    threat_level = "MEDIUM"
else:
    threat_level = "LOW"


confidence = min(100, max(0, abs(anomaly_score) * 100))

# -----------------------------
# Result
# -----------------------------
result = {
    "anomaly_score": anomaly_score,
    "predicted_anomaly": predicted_anomaly,
    "is_threat": bool(predicted_anomaly),
    "threat_level": threat_level,
    "confidence": round(confidence, 2),
    "features_used": user_features
}

print(json.dumps(result, indent=2))
